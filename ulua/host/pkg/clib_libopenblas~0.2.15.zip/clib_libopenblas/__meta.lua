
return {
  name = "clib_libopenblas",
  version = "0.2.15",
  require = {
    luajit = "2.0"
  },
  homepage = "http://www.openblas.net/",
  license  = "BSD",
  description = "OpenBLAS : An optimized BLAS library",
}